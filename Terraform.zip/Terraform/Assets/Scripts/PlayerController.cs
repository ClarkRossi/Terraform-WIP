﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    //Determins player speed
    public float speed;

    //Determins jump height
    public float jumpHeight;

    //Determines how long it takes for player to spawn
    public float spawnTime;

    //Bool to check if player can jump
    public bool isGrounded;

    //Sets number of times player can jump
    public int numJumps;
    int currentNumJumps;

    //Sets player health
    public float playerHealth;

    //Variable to update UI text
    public Text playerHealthText;

    //Variable to hold player spawn position
    public Vector3 spawnPos;

    //Determines the distance at which player can dig and attack
    public float interactDistance;

    //Bool to prevent player input when dead
    public bool playerAlive = true;

    //Holds youDiedText to activate/deactived when player dies
    public GameObject youDiedText;

	// Use this for initialization
	void Start()
    {
        //Sets players initial spawn point to center of world
        GameObject handler = GameObject.Find("Handler");
        spawnPos = new Vector3(handler.GetComponent<GenerateChunks>().chunkSize * handler.GetComponent<GenerateChunks>().worldChunkLength / 2f, 55f, 0f);
        gameObject.transform.position = spawnPos;
    }

	void OnCollisionEnter2D(Collision2D collision)
	{
        if(collision.gameObject.tag == "Enemy")
        {
            //Applies damage to player
            playerHealth -= collision.gameObject.GetComponent<CombatHandler>().attackDamage;

            //Applies knockback to player
            var force = transform.position - collision.transform.position;
            force.Normalize();
            GetComponent<Rigidbody2D>().AddForce(force * collision.gameObject.GetComponent<CombatHandler>().knockback);
        }
    }

	// Update is called once per frame
	void Update ()
    {
        //Updates player health UI with current health
        if (playerHealth >= 0f) //Prevents negative numbers from displaying
            playerHealthText.text = "Health: " + playerHealth;

        //Player horizontal movement
        Rigidbody2D player = GetComponent<Rigidbody2D>();

        if(playerAlive)
            player.velocity = new Vector2(Input.GetAxis("Horizontal") * speed, player.velocity.y);

        //Raycast down looking for object
        RaycastHit2D groundRay = Physics2D.Raycast(transform.position, Vector2.down, 1f);

        //If object found isGrounded is true
        if (groundRay.collider != null)
            isGrounded = true;
        else
            isGrounded = false;

        //Player vertical movement
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded && playerAlive)
        {
            player.velocity = new Vector2(player.velocity.x, jumpHeight);

            //Resets number of times player can jump when touching ground
            currentNumJumps = numJumps; 
            currentNumJumps--;
        }
        else if (Input.GetKeyDown(KeyCode.Space) && currentNumJumps > 0 && playerAlive)
        {
            player.velocity = new Vector2(player.velocity.x, jumpHeight);
            currentNumJumps--;
        } 

        //Flips player sprite
        if (Input.GetAxis("Horizontal") > 0 && playerAlive)
            GetComponent<SpriteRenderer>().flipX = true;
        if (Input.GetAxis("Horizontal") < 0 && playerAlive)
            GetComponent<SpriteRenderer>().flipX = false;

        //Attack and dig tiles
        if (Input.GetButtonDown("Fire1") && playerAlive)
        {
            //Gets mouse pos and raycast tile at mouse pos
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D tileRay = Physics2D.Raycast(transform.position, mousePos - transform.position);

            //Destroyes raycasted tile
            if (tileRay.collider.gameObject.GetComponent<WorldTileData>() != null && tileRay.distance <= interactDistance)
            {
                GetComponent<PlayerInventory>().AddTile(tileRay.collider.gameObject.GetComponent<WorldTileData>().tileType, 1);
                Destroy(tileRay.collider.gameObject);
            }

            //Destroyes raycasted enemies
            if (tileRay.collider.tag == "Enemy" && tileRay.distance <= interactDistance)
            {
                tileRay.collider.GetComponent<ZombieAI>().hits--; //Reduces hits by one when hit
            }
        }

        //Displays you died text when player is dead
        youDiedText.SetActive(!playerAlive);

        //If player "dies" move to spawn after 3 second delay
        if (playerHealth <= 0f)
        {
            playerAlive = false;
            Invoke("RespawnPlayer", spawnTime);
        }
    }

    void RespawnPlayer()
    {
        gameObject.transform.position = spawnPos;

        //Reset health
        playerHealth = 100f;

        //Reactivates movement
        playerAlive = true;
    }
}
