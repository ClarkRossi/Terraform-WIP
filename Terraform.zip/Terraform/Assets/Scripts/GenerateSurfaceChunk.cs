﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateSurfaceChunk : MonoBehaviour
{
    //Game objects for base tile materials
    public GameObject DirtTile, GrassTile, StoneTile;

    //Game objects for resources 
    public GameObject tileCoal, tileIron, tileDiamond, tileGold;

    //Sets odds of mineral spawning in chunk
    public float chanceCoal, chanceIron, chanceDiamond, chanceGold;

    public int width;
    public float heightMultiplier;
    public int heightAddition;

    public float smoothness;

    // Use this for initialization
    void Start()
    {
        GenerateChunk();
    }

    //Generates surface chunks
    void GenerateChunk()
    {
        for (int i = 0; i < width; i++)
        {
            //Generates variability to surface through perlin noise 
            int surf = Mathf.RoundToInt(Mathf.PerlinNoise(0f, (i + transform.position.x) / smoothness) * heightMultiplier) + heightAddition;
            Debug.Log(surf);
            //Generates specific tiles at certian depths  
            for (int depth = 0; depth < surf; depth++)
            {
                GameObject selectedTile;
                if (depth < surf - Random.Range(4.0f, 10.0f)) //Dirt has a random chance of spawning from depth 4-10
                {
                    selectedTile = StoneTile;
                }
                else if (depth < surf - 1)
                {
                    selectedTile = DirtTile;
                }
                else
                {
                    selectedTile = GrassTile;
                }

                //
                GameObject newTile = Instantiate(selectedTile, Vector3.zero, Quaternion.identity) as GameObject;
                newTile.transform.parent = this.gameObject.transform;
                newTile.transform.localPosition = new Vector3(i, depth);
            }
        }
        //
        Populate();
    }

    //Replace with better mineral system
    public void Populate()
    {
        foreach (GameObject t in GameObject.FindGameObjectsWithTag("TileStone"))
        {
            if (t.transform.parent == this.gameObject.transform)
            {
                //
                float r = Random.Range(0f, 100f);
                GameObject selectedTile = null;

                //
                if (r < chanceDiamond)
                {
                    selectedTile = tileDiamond;
                }
                else if (r <= chanceGold)
                {
                    selectedTile = tileGold;
                }
                else if (r < chanceIron)
                {
                    selectedTile = tileIron;
                }
                else if (r < chanceCoal)
                {
                    selectedTile = tileCoal;
                }

                //
                if (selectedTile != null)
                {
                    GameObject newResourceTile = Instantiate(selectedTile, t.transform.position, Quaternion.identity) as GameObject;
                    newResourceTile.transform.parent = transform;
                    Destroy(t);
                }
            }
        }
    }
}
