﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieAI : MonoBehaviour {

    public float speed, jumpHeight; //Zombies speed and jump height
    public float chargeSpeed;
    public float safeFallDistance;
    float changeInSpeed, speedMultiplier; //Accounts for direction changes 
    public float raycastDistance;
    bool isGrounded, hasChanged;
    bool moveLeft; //Bool to change zombies movement direction
    public GameObject groundRaycastPoint, obsticalRaycastPointL, obsticalRaycastPointR; //Offset gameobject raycast points to allow raycasting to enemy
    public int hits; //Determines how many hits enemy takes before dieing

    // Use this for initialization
    void Start ()
    {
        //Sets random starting movement direction
        float rand = Random.Range(0f, 1.0f);
        if (rand > 0.5)
            moveLeft = true;
    }

    // Update is called once per frame
    void Update ()
    {
        //Get rigidbody for zombie
        Rigidbody2D zombieParent = GetComponentInParent<Rigidbody2D>();

        //Racast to determine obsticals in path
        RaycastHit2D obsticalRay;

        //Raycast down looking for object
        RaycastHit2D groundRay = Physics2D.Raycast(groundRaycastPoint.transform.position, Vector2.down, raycastDistance);

        //Raycast down looking for object
        RaycastHit2D fallRay = Physics2D.Raycast(groundRaycastPoint.transform.position, Vector2.down, safeFallDistance);

        //Destroyes zombie if hits falls to 0 or below
        if (hits <= 0)
        {
            //Increases maxAISpawned inSpawnAI script by one
            GameObject.Find("Handler").GetComponent<SpawnAI>().maxAISpawned++;

            //Destroys parent and its self
            Destroy(transform.parent.gameObject);
        }

        //Logic for zombie charging
        if (GetComponentInParent<AICollision>().speedChangeActivated == true)
        {
            speedMultiplier = speed * chargeSpeed;
        }
        else
        {
            speedMultiplier = speed;
        }

        //If object found isGrounded is true
        if (groundRay.collider != null)
            isGrounded = true;
        else
            isGrounded = false;

        //Logic to change directions if fall distance is too great
        if (fallRay.collider == null && !hasChanged)
        {
            moveLeft = !moveLeft;
            hasChanged = true;
        }
        if (isGrounded)
            hasChanged = false;

        //Determines zombie movement and raycast direction
        if (!moveLeft)
        {
            changeInSpeed = speedMultiplier;
            obsticalRay = Physics2D.Raycast(obsticalRaycastPointR.transform.position, Vector2.right, raycastDistance);

            //Flips zombie sprite
            GetComponent<SpriteRenderer>().flipX = true;

            //Reverses box collider
            GetComponentInParent<BoxCollider2D>().offset = new Vector2(1.35f, 0.5f);
        }
        else
        {
            changeInSpeed = -1f * speedMultiplier;
            obsticalRay = Physics2D.Raycast(obsticalRaycastPointL.transform.position, Vector2.left, raycastDistance);

            //Flips zombie sprite
            GetComponent<SpriteRenderer>().flipX = false;

            //Reverses box collider
            GetComponentInParent<BoxCollider2D>().offset = new Vector2(-1.35f, 0.5f);
        }

        //If object infront of zombie and grounded jump
        if (obsticalRay.collider != null && isGrounded)
        {
            //Jump script needs to be better
            zombieParent.velocity = new Vector2(zombieParent.velocity.x, jumpHeight);
        }
        //If cant jump over object change directions 
        else if (obsticalRay.collider != null && !isGrounded)
        {
            moveLeft = !moveLeft;
        }

        //Moves zombie in appropriate direction
        zombieParent.velocity = new Vector2(changeInSpeed, zombieParent.velocity.y);
    }
}
