﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICulling : MonoBehaviour
{
    //Bool to enable/disable culling
    public bool cullingActive;

    //Distance at which AI will be culled
    public float cullingDistanceX, cullingDistanceY;

    //The transform of the player
    Transform playerTransform;

    //The child gameobject of the AI
    public GameObject childComponent;

    //Use this for initialization
    void Start()
    {
        //Gets player transform from
        playerTransform = GameObject.Find("Player").transform;

        //Freezes rigidbody X/Y on cullBox
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePosition;
    }

    //Disables AI after cullingDistance
    void Update()
    {
        //If the player is within cullingDistance +/- that of the AI activate AI
        if ((transform.position.x + cullingDistanceX > playerTransform.position.x) && (transform.position.x - cullingDistanceX < playerTransform.position.x) && (transform.position.y + cullingDistanceY > playerTransform.position.y) && (transform.position.y - cullingDistanceY < playerTransform.position.y) && cullingActive)
        {
            childComponent.SetActive(true);

            //Unfreezes rigidbody
            GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.None;

            //Keeps z rotation frozen to prevent ai rotation
            GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        }
        //Else deactivate AI
        else
        {
            childComponent.SetActive(false);

            //Freezes rigidbody X/Y on cullBox
            GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePosition;
        }
    }
}
