﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkAccess : MonoBehaviour
{
    //Used to access child object in culling script
    public GameObject child;

    //Bool to pass isActive from ChunkCulling
    bool cullingActive;

    void Start()
    {
        //Passes value from ChunkCulling script on camera
        cullingActive = GameObject.Find("MainCamera").GetComponent<ChunkCulling>().cullingActive;

        if (cullingActive)
        {
            child.SetActive(false);
        }
    }
}
