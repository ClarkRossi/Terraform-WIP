﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateLayerThree : MonoBehaviour
{
    //Game objects for base tile materials
    public GameObject ObsidianTile;

    //Game objects for resources 
    public GameObject tileCoal, tileIron, tileDiamond, tileGold;

    //Sets odds of mineral spawning in chunk
    public float chanceCoal, chanceIron, chanceDiamond, chanceGold;

    //Determines chunk size
    int width, height;

    // Use this for initialization
    void Start()
    {
        //Sets width and height addition to chunk size from GenerateChunks
        GameObject theHandler = GameObject.Find("Handler");
        width = theHandler.GetComponent<GenerateChunks>().chunkSize;
        height = theHandler.GetComponent<GenerateChunks>().chunkSize;

        Generate();
    }

    // Update is called once per frame
    void Generate()
    {
        for (int i = 0; i < width; i++)
        {
            //Generates specific tiles at certian depths  
            for (int depth = 0; depth < height; depth++)
            {
                //
                GameObject newTile = Instantiate(ObsidianTile, Vector3.zero, Quaternion.identity) as GameObject;
                newTile.transform.parent = this.gameObject.transform;
                newTile.transform.localPosition = new Vector3(i, depth);
            }
        }
    }
}
