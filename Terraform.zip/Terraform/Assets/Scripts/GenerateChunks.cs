﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateChunks : MonoBehaviour
{
    public GameObject surfaceChunk, layerOneChunk, layerTwoChunk, layerThreeChunk;
    public GameObject transitionChunkOne, transitionChunkTwo;

    [Tooltip("WIP Don't change not working")]
    public int chunkSize;
    public int worldChunkLength, worldChunkHeight;
    float surfSeed, t1Seed, t2Seed;

    //Used to gain access to chunk seed component
    GameObject surfSeedAccess, t1SeedAccess, t2SeedAccess;

    // Use this for initialization
    void Start ()
    {
        //Creates seperate seeds for surface, trasnition 1, and transition 2 layers
        surfSeed = Random.Range(-100000f, 100000f);
        t1Seed = Random.Range(-100000f, 100000f);
        t2Seed = Random.Range(-100000f, 100000f);

        //Sets a gameobject for each of the chunks
        surfSeedAccess = surfaceChunk.GetComponent<ChunkAccess>().child;
        t1SeedAccess = transitionChunkOne.GetComponent<ChunkAccess>().child;
        t2SeedAccess = transitionChunkTwo.GetComponent<ChunkAccess>().child;

        GenerateWorld();
	}
	
	//Logic to create world structure
	public void GenerateWorld()
    {
        //Used to keep track of chunk x and y locations
        int lastX = -chunkSize;
        int lastY = -chunkSize;

        //Creates top level surface
        for (int x = 0; x < worldChunkLength; x++)
        {
            surfSeedAccess.GetComponent<GenerateSurfaceChunk>().seed = surfSeed; //Seeds each newly created surface chunk
            Instantiate(surfaceChunk, new Vector3(lastX + chunkSize, 0f), Quaternion.identity); //Adds to list and creates chunk in world
            lastX += chunkSize;
        }

        //Creates first sub surface layer and sets to 1/4 world height
        for (int y = 0; y < worldChunkHeight / 4; y++)
        {
            lastX = -chunkSize;//Resets X every Y itteration 
            for (int x = 0; x < worldChunkLength; x++)
            {
                //Needs to call seperate subsurface chunk generation script similar to above if
                Instantiate(layerOneChunk, new Vector3(lastX + chunkSize, lastY), Quaternion.identity);
                lastX += chunkSize;
            }
            lastY -= chunkSize;
        }
        
        //Creates first trasition layer 
        lastX = -chunkSize;//Resets X every Y itteration 
        for (int x = 0; x < worldChunkLength; x++)
        {
            //Seeds each newly created t1 chunk
            t1SeedAccess.GetComponent<GenerateTransitionChunk>().seed = t1Seed;

            //Creates first transitional chunk
            Instantiate(transitionChunkOne, new Vector3(lastX + chunkSize, lastY), Quaternion.identity);
            lastX += chunkSize;
        }
        lastY -= chunkSize;

        //Creates second subsurface layer sets to half world height
        for (int y = 0; y < worldChunkHeight / 2; y++)
        {
            lastX = -chunkSize;//Resets X every Y itteration 
            for (int x = 0; x < worldChunkLength; x++)
            {
                Instantiate(layerTwoChunk, new Vector3(lastX + chunkSize, lastY), Quaternion.identity);
                lastX += chunkSize;
            }
            lastY -= chunkSize;
        }
        
        //Creates second trasition layer 
        lastX = -chunkSize;//Resets X every Y itteration 
        for (int x = 0; x < worldChunkLength; x++)
        {
            //Seeds each newly created t2 chunk
            t2SeedAccess.GetComponent<GenerateTransitionChunk>().seed = t2Seed;

            //Creates second transitional chunk
            Instantiate(transitionChunkTwo, new Vector3(lastX + chunkSize, lastY), Quaternion.identity);
            lastX += chunkSize;
        }
        lastY -= chunkSize;

        //Creates last subsurface layer sets to 1/4 world height
        for (int y = 0; y < worldChunkHeight / 4; y++)
        {
            lastX = -chunkSize;//Resets X every Y itteration 
            for (int x = 0; x < worldChunkLength; x++)
            {
                Instantiate(layerThreeChunk, new Vector3(lastX + chunkSize, lastY), Quaternion.identity);
                lastX += chunkSize;
            }
            lastY -= chunkSize;
        }
    }
}
