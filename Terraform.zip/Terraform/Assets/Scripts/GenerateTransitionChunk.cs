﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateTransitionChunk : MonoBehaviour
{
    public GameObject StoneTile, GraniteTile, ObsidianTile;

    public int width;
    public float depthMultiplier;
    int depthAddition;

    public float smoothness;

    // Use this for initialization
    void Start ()
    {
        GenerateTransition();
	}
	
	//Generates transitional chunk
	void GenerateTransition()
    {
        //Used to change tile
        GameObject selectedTile;

        //Generates stone and granite transitional layer
        if (StoneTile != null)
        {
            for (int i = 0; i < width; i++)
            {
                depthAddition = Random.Range(8, 12);
                int transitionPoint = Mathf.RoundToInt(Mathf.PerlinNoise(0f, (i + transform.position.x) / smoothness) * depthMultiplier) + depthAddition;

                //Generates specific tiles at certian depths  
                for (int depth = 0; depth < 25; depth++)
                {
                    //Top half
                    if (depth > transitionPoint)
                    {
                        selectedTile = StoneTile;
                    }
                    //Bottom half
                    else
                    {
                        selectedTile = GraniteTile;
                    }
                    GameObject newTile = Instantiate(selectedTile, Vector3.zero, Quaternion.identity) as GameObject;
                    newTile.transform.parent = this.gameObject.transform;
                    newTile.transform.localPosition = new Vector3(i, depth);
                }
            }
        }
        //Generates granite and obsidian transitional layer
        else
        {
            for (int i = 0; i < width; i++)
            {
                depthAddition = Random.Range(8, 12);
                int transitionPoint = Mathf.RoundToInt(Mathf.PerlinNoise(0f, (i + transform.position.x) / smoothness) * depthMultiplier) + depthAddition;

                //Generates specific tiles at certian depths  
                for (int depth = 0; depth < 25; depth++)
                {
                    //Top half
                    if (depth > transitionPoint)
                    {
                        selectedTile = GraniteTile;
                    }
                    //Bottom half
                    else
                    {
                        selectedTile = ObsidianTile;
                    }
                    GameObject newTile = Instantiate(selectedTile, Vector3.zero, Quaternion.identity) as GameObject;
                    newTile.transform.parent = this.gameObject.transform;
                    newTile.transform.localPosition = new Vector3(i, depth);
                }
            }
        }
	}
}
