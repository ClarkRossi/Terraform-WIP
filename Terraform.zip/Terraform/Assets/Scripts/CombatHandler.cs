﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatHandler : MonoBehaviour 
{
    public float attackDamage;
    public float knockback;
}
