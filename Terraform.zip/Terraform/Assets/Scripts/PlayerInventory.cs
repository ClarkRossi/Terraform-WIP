﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerInventory : MonoBehaviour {

    //Used to display inventory items
    public Text inventoryText, selectionText;

    //Array to hold number of items in inventory 
    int[] counts = new int[9];

    //Holds correlating number for tile
    int selectedTile;

    //Array holding names of tiles for selectionText
    string[] tileNames = new string[] {"Grass", "Dirt", "Stone", "Granite", "Obsidian", "Coal", "Iron", "Gold", "Diamond"};

    //Array to hold tile GameObjects
    public GameObject[] tiles = new GameObject[9];

	// Update is called once per frame
	void Update ()
    {
        //Displays intventory items and quantity 
        inventoryText.text = "Grass: " + counts[0] + "\nDirt: " + counts[1] + "\nStone: " + counts[2] + "\nGranite: " + counts[3] + "\nObsidian: " + counts[4] + "\nCoal: " + counts[5] + "\nIron: " + counts[6] + "\nGold: " + counts[7] + "\nDiamond: " + counts[8];

        //Prevents selection overflow
        if (selectedTile < 0)
            selectedTile = counts.Length - 1;
        else if (selectedTile > counts.Length - 1)
            selectedTile = 0;

        //Navagates through selected tiles
        if (Input.GetKeyDown(KeyCode.UpArrow))
            selectedTile++;
        else if (Input.GetKeyDown(KeyCode.DownArrow))
            selectedTile--;

        //Sets selected tile to appropriate tile name
        selectionText.text = "Selected Tile: " + tileNames[selectedTile];

        //Places selected tile in inventory
        if (Input.GetButtonDown("Fire2") && counts[selectedTile] > 0)
        {
            //Gets mouse position relative to camera
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            //Selects the position to place tile
            Vector3 placePos = new Vector3(Mathf.Round(mousePos.x), Mathf.Round(mousePos.y), 0f);

            //Places tile if no current is at location
            if (Physics2D.OverlapCircleAll(placePos, 0.25f).Length == 0)
            {
                //Places and removes tile from inventory
                GameObject newTile = Instantiate(tiles[selectedTile], placePos, Quaternion.identity) as GameObject;
                counts[selectedTile]--;
            }
        }
	}

    //Function to add tiles to player inventory
    public void AddTile(int tileType, int count)
    {
        counts[tileType] += count;
    }
}
