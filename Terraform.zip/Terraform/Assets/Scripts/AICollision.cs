﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICollision : MonoBehaviour
{
    //Public bool to pass collision state for ZombieAI
    public bool speedChangeActivated;

    void OnTriggerEnter2D(Collider2D collision)
    {
        //Increases zombie speed when player is spotted
        if (collision.gameObject.tag == "Player")
        {
            speedChangeActivated = true;
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        //Increases zombie speed when player is spotted
        if (collision.gameObject.tag == "Player")
        {
            speedChangeActivated = false;
        }
    }
}
