﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkCulling : MonoBehaviour
{
    //Bool to enable/disable culling
    public bool cullingActive;

    // Use this for initialization
    void Start()
    {

    }

    //Reactivates gameObject chunk in camera collider
    void OnTriggerEnter2D(Collider2D collision)
    {
        //Adds collided gameObject to list
        if (collision.gameObject.tag == "ChunkCullBox" && cullingActive)
        {
            //Gets gameObject from ChunkAccess script
            GameObject childChunk = collision.gameObject.GetComponent<ChunkAccess>().child;
            childChunk.gameObject.SetActive(true);
        }
    }

    //Deactivates gameObject when exits camera collider
    void OnTriggerExit2D(Collider2D collision)
    {
        //Adds collided gameObject to list
        if (collision.gameObject.tag == "ChunkCullBox" && cullingActive)
        {
            //Gets gameObject from ChunkAccess script
            GameObject childChunk = collision.gameObject.GetComponent<ChunkAccess>().child;
            childChunk.gameObject.SetActive(false);
        }
    }
}