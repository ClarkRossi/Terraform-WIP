﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldTileData : MonoBehaviour
{
    //Holds an int to represent tile used by other scripts
    public int tileType;
}
