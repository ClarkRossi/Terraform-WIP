﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//For debugging and testing chunks
public class TestChunk : MonoBehaviour {

    public int worldChunkLength;
    public GameObject testChunk;
    private int chunkSize = 25;

    // Use this for initialization
    void Start () {
        GenerateTest();
	}
	
	// Update is called once per frame
	void GenerateTest()
    {
        int lastX = -chunkSize;
        for (int x = 0; x < worldChunkLength; x++)
        {
            Instantiate(testChunk, new Vector3(lastX + chunkSize, 0f), Quaternion.identity);
            lastX += chunkSize;
        }
    }
}
