﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnAI : MonoBehaviour
{
    //Determines the amount of enemies spawned
    public int maxAISpawned;

    // Use this for initialization
    void Start ()
    {
        //Sets the amount of enemies spawned equal to 1/4th the world size
        maxAISpawned = gameObject.GetComponent<GenerateChunks>().worldChunkLength / 4;

        //Handles the bulk of the spawning 
        while(maxAISpawned > 0)
        {
            float randSpawnX = Random.Range(0f, gameObject.GetComponent<GenerateChunks>().chunkSize * gameObject.GetComponent<GenerateChunks>().worldChunkLength);

            GameObject myRoadInstance = Instantiate(Resources.Load("ZombieCullBox"), new Vector3(randSpawnX, 45, 0), Quaternion.identity) as GameObject;
            maxAISpawned--;
        }
    }
	
	// Update is called once per frame
	void Update ()
    {
        //Creates a random number within the world size
        float randSpawnX = Random.Range(0f, gameObject.GetComponent<GenerateChunks>().chunkSize * gameObject.GetComponent<GenerateChunks>().worldChunkLength);

        //Checks if more ai need to be spawned
        if (maxAISpawned > 0)
        {
            GameObject myRoadInstance = Instantiate(Resources.Load("ZombieCullBox"), new Vector3(randSpawnX, 45, 0), Quaternion.identity) as GameObject;
            maxAISpawned--;
        }
    }
}
