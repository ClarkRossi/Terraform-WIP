﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateLayerOne : MonoBehaviour
{
    //Game objects for base tile materials
    public GameObject StoneTile;

    //Determines chunk size
    public int width, height;

    // Use this for initialization
    void Start()
    {
        Generate();
    }

    // Update is called once per frame
    void Generate()
    {
        for (int i = 0; i < width; i++)
        {
            //Generates specific tiles at certian depths  
            for (int depth = 0; depth < height; depth++)
            {
                //
                GameObject newTile = Instantiate(StoneTile, Vector3.zero, Quaternion.identity) as GameObject;
                newTile.transform.parent = this.gameObject.transform;
                newTile.transform.localPosition = new Vector3(i, depth);
            }
        }
    }
}
